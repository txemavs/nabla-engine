# Changelog

## Unreleased — Phase 4

- Add optional same-origin detached browser views with cloned snapshots and owner-dispatched actions.
- Handle duplicate focus, popup blocking, close/reopen, owner teardown, stale actions and renderer cleanup.
- Add a synchronized inspector to the demo and packed consumers, with browser lifecycle tests.
- Document single-owner rendering, browser constraints, CSP/style ownership and reconnection limits.

## Unreleased — Phase 3

- Add a pure workspace model with tabs, splits, docking, floating groups and validated version-1 snapshots.
- Add WorkspaceHost with stable content identity, keyboard/pointer layout controls and small-container bounds.
- Add async document-close guards, DesktopDialog, DesktopButton, SettingsGroup and StatusBar.
- Extend the lab and both packed consumers with live native/Vue workspace content and persistence.
- Document migration, ownership, keyboard/localization contracts and remaining control/browser limitations.

## Unreleased — Phase 2

- Default to foreground maximization; background world mode remains opt-in.
- Add framework-independent commands and external-content lifecycle adapters through `@nabla/desktop/core`.
- Add menu bar, nested/context menus, toolbar, scoped shortcuts and inherited theme tokens.
- Extend the interactive lab with native canvas content, linked commands and light/dark themes.
- Document input ownership, lifecycle, browser requirements and migration boundaries.

## Unreleased — Phase 1

- Export the stylesheet and place TypeScript declarations first in package exports.
- Validate packaged consumers with Pinia 2 and Agency's Vue/Pinia 4/Vuetify profile.
- Add explicitly named desktop store factories and isolate counters and timers.
- Repair active-window and registration/maximization invariants.
- Measure WindowHost containers, constrain geometry and support explicit viewport mode.
- Provide explicit background and exclusive maximization policies.
- Add hide/dispose close policies and opt-in retained content after close.
- Clean up pointer gestures and timers; avoid lagging drag/resize transitions.
- Add distribution/browser tests and document public contracts and migration differences.

Menus, tabs, docking, persistence and detached-browser-window adapters remain on
the shared roadmap and are not included in this phase.
